import { create } from 'zustand';
import { Phone } from './types';

interface AppState {
  favorites: number[];
  comparison: number[];
  darkMode: boolean;
  toggleFavorite: (id: number) => void;
  toggleComparison: (id: number) => void;
  toggleTheme: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  favorites: [],
  comparison: [],
  darkMode: true,
  toggleFavorite: (id) => set((state) => ({
    favorites: state.favorites.includes(id) 
      ? state.favorites.filter((f) => f !== id) 
      : [...state.favorites, id]
  })),
  toggleComparison: (id) => set((state) => ({
    comparison: state.comparison.includes(id) 
      ? state.comparison.filter((c) => c !== id) 
      : [...state.comparison, id]
  })),
  toggleTheme: () => set((state) => ({ darkMode: !state.darkMode })),
}));
