import { Phone } from './types';
import phonesDataRaw from './phones_data.json';

export const catalogData: Phone[] = phonesDataRaw as Phone[];

export const brands = Array.from(new Set(catalogData.map(p => p.brand))).sort();
export const categories = Array.from(new Set(catalogData.flatMap(p => p.categories))).sort();
