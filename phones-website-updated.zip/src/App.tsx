import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Catalog from './pages/Catalog';
import PhoneDetails from './pages/PhoneDetails';
import BrandDetails from './pages/BrandDetails';
import { useAppStore } from './store';

export default function App() {
  const darkMode = useAppStore((state) => state.darkMode);

  return (
    <div className={darkMode ? 'dark' : ''}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/catalog" element={<Catalog />} />
          <Route path="/phone/:id" element={<PhoneDetails />} />
          <Route path="/brand/:brand" element={<BrandDetails />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}
