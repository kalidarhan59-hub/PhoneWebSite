export default function Footer() {
  return (
    <footer className="border-t border-slate-100 mt-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-6 py-8 flex items-center justify-between text-[11px] text-slate-400 uppercase tracking-widest font-bold">
        <p>&copy; 2026 Phones Web. All rights reserved.</p>
        <div className="flex gap-8">
          <a href="#" className="hover:text-black">Доставка</a>
          <a href="#" className="hover:text-black">Гарантия</a>
          <a href="#" className="hover:text-black">Контакты</a>
        </div>
      </div>
    </footer>
  );
}
