import { Link } from 'react-router-dom';

export default function Header() {
  return (
    <header className="sticky top-0 bg-white/80 backdrop-blur-xl z-40 border-b border-slate-100">
      <nav className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="bg-blue-600 text-white p-2 rounded-xl group-hover:rotate-12 transition-transform">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
            </svg>
          </div>
          <div className="text-2xl font-black tracking-tighter text-slate-900">
            PHONES<span className="text-blue-600">DB</span>
          </div>
        </Link>
        
        <div className="flex items-center gap-8">
          <div className="hidden md:flex gap-6 text-sm font-bold text-slate-500">
            <Link to="/" className="hover:text-blue-600 transition-colors">Главная</Link>
            <Link to="/catalog" className="hover:text-blue-600 transition-colors">Каталог</Link>
          </div>
          
          <Link 
            to="/catalog" 
            className="bg-slate-900 text-white px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-blue-600 transition-all shadow-lg shadow-slate-200"
          >
            Смотреть 200+ моделей
          </Link>
        </div>
      </nav>
    </header>
  );
}
