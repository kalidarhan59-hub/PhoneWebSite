import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { catalogData } from '../data';

export default function Hero() {
  const phones = catalogData.slice(0, 4);

  return (
    <section className="relative h-screen flex justify-center items-center overflow-hidden bg-[radial-gradient(circle_at_center,#5b2cff44,transparent_55%),linear-gradient(180deg,#090b18,#0f1026,#090b18)]">
      {/* Phones */}
      {phones.map((phone, index) => (
        <motion.img
          key={phone.id}
          src={phone.imageUrl}
          alt={phone.model}
          className={`absolute w-64 object-contain filter drop-shadow-[0_0_40px_rgba(100,80,255,0.5)] ${
            index === 0 ? 'left-[5%] top-[18%] -rotate-[25deg]' :
            index === 1 ? 'left-[10%] bottom-[8%] rotate-[18deg]' :
            index === 2 ? 'right-[6%] top-[10%] rotate-[25deg]' :
            'right-[8%] bottom-[10%] -rotate-[20deg]'
          }`}
          animate={{ y: [0, -20, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          onError={(e) => { e.currentTarget.src = `https://placehold.co/600x600/f1f5f9/475569?text=${encodeURIComponent(phone.model)}` }}
        />
      ))}

      {/* Content */}
      <div className="text-center text-white z-10 px-6">
        <h1 className="text-5xl md:text-7xl font-extrabold leading-[1.1] max-w-[900px]">
          Найди свой идеальный смартфон
        </h1>
        <p className="mt-6 text-xl md:text-2xl opacity-90">
          Обзоры, сравнения и подборки лучших устройств<br /> для любых задач — от тяжелых игр до учебы.
        </p>
        <Link to="/catalog" className="inline-block mt-10 bg-white text-black px-12 py-5 rounded-full text-xl font-medium transition hover:translate-y-[-3px] hover:shadow-[0_15px_40px_rgba(123,90,255,0.4)]">
          Смотреть каталог
        </Link>
      </div>
    </section>
  );
}
