import { Link } from 'react-router-dom';
import { Phone } from '../types';
import { useAppStore } from '../store';
import { Heart, Scale } from 'lucide-react';

export default function PhoneCard({ phone }: { phone: Phone }) {
  const { toggleFavorite, toggleComparison, favorites, comparison } = useAppStore();

  const isFavorite = favorites.includes(phone.id);
  const isComparing = comparison.includes(phone.id);

  return (
    <div className="bg-white/5 backdrop-blur-md rounded-2xl p-4 border border-white/10 hover:border-indigo-500/50 transition-all group">
      <Link to={`/phone/${phone.id}`}>
        <img src={phone.imageUrl} alt={phone.model} className="w-full h-48 object-contain mb-4" />
        <h3 className="text-lg font-bold text-white mb-1">{phone.model}</h3>
        <p className="text-slate-400 text-sm mb-4">{phone.brand}</p>
      </Link>
      <div className="flex justify-between items-center">
        <button onClick={() => toggleFavorite(phone.id)} className={`p-2 rounded-full transition ${isFavorite ? 'text-red-500 bg-red-500/10' : 'text-slate-400 hover:text-white'}`}>
          <Heart size={20} />
        </button>
        <button onClick={() => toggleComparison(phone.id)} className={`p-2 rounded-full transition ${isComparing ? 'text-indigo-400 bg-indigo-400/10' : 'text-slate-400 hover:text-white'}`}>
          <Scale size={20} />
        </button>
      </div>
    </div>
  );
}
