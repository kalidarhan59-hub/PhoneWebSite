import { Phone } from '../types';

interface ProductCardProps {
  phone: Phone;
  onClick: (phone: Phone) => void;
}

export default function ProductCard({ phone, onClick }: ProductCardProps) {
  return (
    <div 
      className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer hover:-translate-y-2 border border-slate-100 group"
      onClick={() => onClick(phone)}
    >
      <div className="relative h-56 w-full mb-6 flex items-center justify-center bg-slate-50 rounded-xl overflow-hidden">
        <img 
          src={phone.imageUrl} 
          alt={phone.model} 
          className="h-48 w-auto object-contain transition-transform duration-500 group-hover:scale-110"
          onError={(e) => { e.currentTarget.src = `https://placehold.co/600x600/f1f5f9/475569?text=${encodeURIComponent(phone.model)}` }}
        />
        <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-[10px] font-bold text-slate-600 shadow-sm">
          {phone.releaseYear}
        </div>
      </div>
      
      <div className="space-y-1">
        <span className="text-[10px] uppercase tracking-widest text-blue-500 font-black">{phone.brand}</span>
        <h3 className="text-lg font-bold text-slate-900 truncate group-hover:text-blue-600 transition-colors">{phone.model}</h3>
        <div className="flex justify-between items-center pt-2">
          <span className="text-sm font-black text-slate-900">${phone.price}</span>
          <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full font-bold">
            {phone.categories[0]}
          </span>
        </div>
      </div>
    </div>
  );
}
