import { useState, useMemo } from 'react';
import { catalogData, brands } from '../data';
import ProductCard from './ProductCard';
import { Phone } from '../types';

interface ProductGridProps {
  onPhoneClick: (phone: Phone) => void;
}

export default function ProductGrid({ onPhoneClick }: ProductGridProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredPhones = useMemo(() => {
    return catalogData.filter(phone => {
      const matchesSearch = 
        phone.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
        phone.brand.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesBrand = selectedBrand === 'all' || phone.brand === selectedBrand;
      
      const matchesCategory = selectedCategory === 'all' || phone.categories.includes(selectedCategory);

      return matchesSearch && matchesBrand && matchesCategory;
    });
  }, [searchQuery, selectedBrand, selectedCategory]);

  return (
    <section className="max-w-7xl mx-auto px-6 py-12">
      {/* Filters & Search */}
      <div className="mb-12 space-y-6">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative w-full md:w-96">
            <input
              type="text"
              placeholder="Поиск по модели или бренду..."
              className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <svg className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>

          <div className="flex gap-3 overflow-x-auto pb-2 w-full md:w-auto">
            <select 
              className="px-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm font-bold text-slate-700"
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
            >
              <option value="all">Все бренды</option>
              {brands.map(brand => (
                <option key={brand} value={brand}>{brand}</option>
              ))}
            </select>

            <select 
              className="px-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm font-bold text-slate-700"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="all">Все категории</option>
              <option value="Флагманы">Флагманы</option>
              <option value="Средний класс">Средний класс</option>
              <option value="Бюджетные">Бюджетные</option>
            </select>
          </div>
        </div>
      </div>

      <div className="flex justify-between items-end mb-8">
        <div>
          <h2 className="text-3xl font-black text-slate-900">Каталог смартфонов</h2>
          <p className="text-slate-500 font-medium">Найдено {filteredPhones.length} моделей</p>
        </div>
      </div>

      {filteredPhones.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {filteredPhones.map(phone => (
            <ProductCard key={phone.id} phone={phone} onClick={onPhoneClick} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
          <p className="text-slate-400 text-lg font-bold">Ничего не найдено по вашему запросу</p>
          <button 
            onClick={() => {setSearchQuery(''); setSelectedBrand('all'); setSelectedCategory('all');}}
            className="mt-4 text-blue-500 font-bold hover:underline"
          >
            Сбросить фильтры
          </button>
        </div>
      )}
    </section>
  );
}
