import { Phone } from '../types';

export default function Modal({ phone, onClose }: { phone: Phone, onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto" onClick={onClose}>
      <div className="bg-white rounded-3xl p-6 md:p-10 max-w-4xl w-full relative my-8" onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-6 right-6 text-slate-400 hover:text-black bg-slate-100 p-2 rounded-full transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {/* Left Column: Image and Basic Info */}
          <div className="space-y-6">
            <div className="bg-slate-50 rounded-2xl p-6 flex items-center justify-center">
              <img 
                src={phone.imageUrl} 
                alt={phone.model} 
                className="max-h-[400px] w-auto object-contain"
                onError={(e) => { e.currentTarget.src = `https://placehold.co/600x800/f1f5f9/475569?text=${encodeURIComponent(phone.model)}` }}
              />
            </div>
            
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="bg-blue-100 text-blue-700 text-xs font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                  {phone.brand}
                </span>
                <span className="bg-slate-100 text-slate-600 text-xs font-bold px-2.5 py-1 rounded-full">
                  {phone.releaseYear} год
                </span>
              </div>
              <h2 className="text-4xl font-black text-slate-900 leading-tight mb-4">{phone.model}</h2>
              <p className="text-slate-600 text-lg leading-relaxed">{phone.description}</p>
              
              <div className="mt-6 space-y-3">
                <div className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="text-slate-500 font-medium">Производитель:</span>
                  <span className="text-slate-900 font-bold">{phone.manufacturer} ({phone.country})</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="text-slate-500 font-medium">Материалы:</span>
                  <span className="text-slate-900 font-bold">{phone.materials}</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="text-slate-500 font-medium">Кому подходит:</span>
                  <span className="text-slate-900 font-bold">{phone.suitableFor}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Technical Specs */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
              </svg>
              Технические характеристики
            </h3>
            
            <div className="grid grid-cols-1 gap-4">
              {Object.entries(phone.specs).map(([key, value]) => (
                <div key={key} className="bg-slate-50 p-3 rounded-xl flex flex-col">
                  <span className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-1">
                    {translateSpecKey(key)}
                  </span>
                  <span className="text-slate-800 font-semibold">{value}</span>
                </div>
              ))}
            </div>

            <div className="bg-blue-50 p-6 rounded-2xl">
              <h4 className="font-bold text-blue-900 mb-3">Особенности:</h4>
              <ul className="grid grid-cols-1 gap-2">
                {phone.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-blue-800">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function translateSpecKey(key: string): string {
  const translations: Record<string, string> = {
    screen: "Экран",
    processor: "Процессор",
    ram: "Оперативная память",
    storage: "Накопитель",
    mainCamera: "Основная камера",
    selfieCamera: "Селфи камера",
    battery: "Аккумулятор",
    charging: "Зарядка",
    os: "Операционная система",
    weight: "Вес",
    dimensions: "Габариты",
    protection: "Защита",
    sim: "SIM-карты",
    other: "Прочее"
  };
  return translations[key] || key;
}
