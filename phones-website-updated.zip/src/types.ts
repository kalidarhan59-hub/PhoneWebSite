export interface Phone {
  id: number;
  brand: string;
  model: string;
  price: number;
  categories: string[];
  description: string;
  imageUrl: string;
  releaseYear: number;
  manufacturer: string;
  country: string;
  materials: string;
  suitableFor: string;
  features: string[];
  
  // Технические характеристики
  specs: {
    screen: string;
    processor: string;
    ram: string;
    storage: string;
    mainCamera: string;
    selfieCamera: string;
    battery: string;
    charging: string;
    os: string;
    weight: string;
    dimensions: string;
    protection: string;
    sim: string;
    other: string;
  };
}
