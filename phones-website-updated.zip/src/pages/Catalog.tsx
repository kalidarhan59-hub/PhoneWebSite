import { useState, useMemo } from 'react';
import { catalogData, brands } from '../data';
import ProductCard from '../components/ProductCard';
import Modal from '../components/Modal';
import { Phone } from '../types';

const CATEGORIES = ["Все категории", "Флагманы", "Средний класс", "Бюджетные"];

const SORT_OPTIONS = [
  { value: "default", label: "По умолчанию" },
  { value: "name_asc", label: "По названию (А-Я)" },
  { value: "name_desc", label: "По названию (Я-А)" },
  { value: "price_asc", label: "Сначала дешевые" },
  { value: "price_desc", label: "Сначала дорогие" },
  { value: "year_desc", label: "Сначала новые" }
];

export default function Catalog() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Все категории');
  const [selectedBrand, setSelectedBrand] = useState('Все бренды');
  const [sortOption, setSortOption] = useState('default');
  const [selectedPhone, setSelectedPhone] = useState<Phone | null>(null);

  const filteredAndSortedPhones = useMemo(() => {
    let result = catalogData;

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(phone => 
        phone.model.toLowerCase().includes(q) || 
        phone.brand.toLowerCase().includes(q)
      );
    }

    if (selectedCategory !== 'Все категории') {
      result = result.filter(phone => phone.categories.includes(selectedCategory));
    }

    if (selectedBrand !== 'Все бренды') {
      result = result.filter(phone => phone.brand === selectedBrand);
    }

    result = [...result].sort((a, b) => {
      switch (sortOption) {
        case 'name_asc': return a.model.localeCompare(b.model);
        case 'name_desc': return b.model.localeCompare(a.model);
        case 'price_asc': return a.price - b.price;
        case 'price_desc': return b.price - a.price;
        case 'year_desc': return b.releaseYear - a.releaseYear;
        default: return 0;
      }
    });

    return result;
  }, [searchQuery, selectedCategory, selectedBrand, sortOption]);

  return (
    <div className="bg-slate-50 min-h-screen text-slate-900 pb-20">
      {/* Hero / Header Section */}
      <div className="bg-white border-b border-slate-200 py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-5xl font-black mb-4 tracking-tight">Каталог <span className="text-blue-600">200+</span> моделей</h1>
          <p className="text-slate-500 text-lg font-medium max-w-2xl">
            Самая полная база смартфонов с подробными техническими характеристиками, 
            описанием материалов и рекомендациями по выбору.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 -mt-8">
        {/* Filters Panel */}
        <div className="bg-white p-6 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100 flex flex-col lg:flex-row gap-4 items-center">
          <div className="relative flex-1 w-full">
            <input 
              type="text" 
              placeholder="Поиск по названию или бренду..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border-none rounded-2xl px-12 py-4 focus:ring-2 focus:ring-blue-500 font-medium"
            />
            <svg className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>

          <div className="flex flex-wrap gap-3 w-full lg:w-auto">
            <select 
              value={selectedBrand} 
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="bg-slate-50 border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-blue-500 font-bold text-slate-700 cursor-pointer"
            >
              <option value="Все бренды">Все бренды</option>
              {brands.map(brand => (
                <option key={brand} value={brand}>{brand}</option>
              ))}
            </select>

            <select 
              value={selectedCategory} 
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-slate-50 border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-blue-500 font-bold text-slate-700 cursor-pointer"
            >
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>

            <select 
              value={sortOption} 
              onChange={(e) => setSortOption(e.target.value)}
              className="bg-slate-50 border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-blue-500 font-bold text-slate-700 cursor-pointer"
            >
              {SORT_OPTIONS.map(sort => (
                <option key={sort.value} value={sort.value}>{sort.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Results Info */}
        <div className="flex justify-between items-center mt-10 mb-8">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></span>
            <span className="text-slate-500 font-bold text-sm uppercase tracking-widest">
              Найдено: {filteredAndSortedPhones.length} моделей
            </span>
          </div>
        </div>

        {/* Grid */}
        {filteredAndSortedPhones.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredAndSortedPhones.map(phone => (
              <ProductCard 
                key={phone.id} 
                phone={phone} 
                onClick={(p) => setSelectedPhone(p)} 
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-32 bg-white rounded-3xl border-2 border-dashed border-slate-200">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-xl font-bold text-slate-900">Ничего не нашли</h3>
            <p className="text-slate-500 mt-2">Попробуйте изменить параметры поиска или фильтры</p>
            <button 
              onClick={() => {setSearchQuery(''); setSelectedBrand('Все бренды'); setSelectedCategory('Все категории');}}
              className="mt-6 bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors"
            >
              Сбросить всё
            </button>
          </div>
        )}
      </div>

      {/* Modal */}
      {selectedPhone && (
        <Modal 
          phone={selectedPhone} 
          onClose={() => setSelectedPhone(null)} 
        />
      )}
    </div>
  );
}
