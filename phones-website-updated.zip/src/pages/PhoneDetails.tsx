export default function PhoneDetails() { return <div className="text-white">Phone Details</div>; }
