export default function BrandDetails() { return <div className="text-white">Brand Details</div>; }
